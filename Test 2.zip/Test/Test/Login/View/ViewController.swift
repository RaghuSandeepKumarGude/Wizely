//
//  ViewController.swift
//  Test
//
//  Created by mituser on 06/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import UIKit
import SVProgressHUD

class ViewController: UIViewController {
//    var loginModel:LoginModel?
    @IBOutlet var repositoryName: UITextField!
    @IBOutlet var organizationName: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
//    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
//        super.init(nibName: "ViewController", bundle: nil)
//    }
//
//    convenience init(loginModel: LoginModel = LoginModel()) {
//        self.init()
//        self.loginModel = loginModel
//    }
//
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    
    @IBAction func submitRepositoryDetails(_ sender: Any) {
        SVProgressHUD.show()
        SVProgressHUD.setBackgroundColor(.lightGray)
        let loginModel = LoginModel()
        let viewModelInstanse = LoginViewModel(model: loginModel)
        viewModelInstanse.fetchRepositoryList(withRepoName: repositoryName.text!, OrganizationName: organizationName.text!) { [weak self] (responseData, err) in
            DispatchQueue.main.async {
                SVProgressHUD.dismiss()
                guard err == nil else {
                    self?.showErrorAlert()
                    return
                }
                let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RepositoryDetailViewController") as? RepositoryDetailViewController
                vc?.dataModel = responseData
                self?.navigationController?.pushViewController(vc!, animated: true)
            }
        }
    }
    
    private func showErrorAlert() {
        let alert = UIAlertController(title: "Something went wrong", message: "Check Entered Details", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

