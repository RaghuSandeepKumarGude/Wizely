//
//  LoginModel.swift
//  Test
//
//  Created by mituser on 07/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import UIKit

enum FeedError: Error {
    case invalidUrl
    case noResultsFound
}

typealias responseHandler = (News?, Error?) -> Void

class LoginModel: NSObject, LoginModelProtocol {
    private var session: URLSession
    var baseUrl = "http://api.github.com/repos"
    init(session: URLSession) {
        self.session = session
    }
    
    convenience override init () {
        self.init(session: URLSession(configuration: .default))
    }
    
    func makeListOfGitRepoRequest(withRepoName: String, OrganizationName: String, completionhandlers: @escaping responseHandler) {
        popularRepos(withRepoName: withRepoName, OrganizationName: OrganizationName, completion: completionhandlers)
    }
    
    private func popularRepos(withRepoName: String, OrganizationName: String, completion: @escaping responseHandler) {
        var  gitRepoString =  OrganizationName.appendingPathComponent(withRepoName)
        gitRepoString = baseUrl + gitRepoString
        
        guard let gitRepoUrl = URL(string: gitRepoString) else {
            completion(nil, FeedError.invalidUrl)
            return
        }
        let task =  session.dataTask(with: gitRepoUrl) { (data, _, error) in
            guard let responseData = data, error == nil else {
                completion(nil, error)
                return
            }
            do {
                let decoder = JSONDecoder()
                let feed = try decoder.decode(News.self, from: responseData)
                print(feed)
                completion(feed, nil)
            } catch let error {
                NSLog("json error: \(error)")
                completion(nil, error)
            }
        }
        task.resume()
    }
}

extension String {
    func appendingPathComponent(_ string: String) -> String {
        return URL(fileURLWithPath: self).appendingPathComponent(string).path
    }
}
