//
//  LoginModelProtocol.swift
//  Test
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
protocol  LoginModelProtocol {
    func makeListOfGitRepoRequest(withRepoName: String, OrganizationName: String, completionhandlers: @escaping responseHandler)
}
