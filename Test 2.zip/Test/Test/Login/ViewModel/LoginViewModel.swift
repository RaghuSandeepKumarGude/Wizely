//
//  LoginViewModel.swift
//  Test
//
//  Created by mituser on 07/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import UIKit

class LoginViewModel: NSObject, LoginViewModelProtocol {
    var model: LoginModelProtocol?
    
    init(model: LoginModelProtocol) {
        self.model = model
    }
    
    func fetchRepositoryList(withRepoName: String, OrganizationName: String, completion: @escaping responseHandler) {
        model?.makeListOfGitRepoRequest(withRepoName: withRepoName, OrganizationName: OrganizationName) { (responseData, err) in
            completion(responseData, err)
        }
    }
    
    
    
    
    
    
    
    
    
    
}
