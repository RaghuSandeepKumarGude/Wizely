//
//  LoginViewModelProtocol.swift
//  Test
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation

protocol  LoginViewModelProtocol {
    func fetchRepositoryList(withRepoName: String, OrganizationName: String, completion: @escaping responseHandler)
}
