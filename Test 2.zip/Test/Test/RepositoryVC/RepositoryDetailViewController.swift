//
//  RepositoryDetailViewController.swift
//  Test
//
//  Created by mituser on 07/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import UIKit
import SDWebImage
import SVProgressHUD

class RepositoryDetailViewController: UIViewController {
    var navigationVC: UINavigationController?
    public var dataModel: News?
    @IBOutlet var gitDescriptionTextView: UITextView!
    @IBOutlet var languagelabel: UILabel!
    @IBOutlet var repoImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let organization = dataModel?.name {
            title = organization
        }
        if let lang = dataModel?.language {
            languagelabel.text = "Language : " + lang
        }
        
        if let desc = dataModel?.fullDescription {
            gitDescriptionTextView.text = desc
        }
        
        if let avatarURL = dataModel?.ownerEntity?.avatarUrl {
            repoImage.sd_setImage(with: URL(string: avatarURL),
                                  placeholderImage: UIImage(named: "Thumbnail"),
                                  options: .retryFailed,
                                  completed: nil)
        }
    }
    
    @IBAction func statusOfTheIssues(_ sender:UIButton) {
        let selectedButton = sender as UIButton
        let seelctedButtonTitle = selectedButton.titleLabel?.text == "Open Isseus" ? "open" : "closed"
        let extention = "/issues?state=" + seelctedButtonTitle
        guard var issuesStatusUrl = dataModel?.url else { return }
        issuesStatusUrl = issuesStatusUrl + extention
        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "RepositoryIssuesViewController") as? RepositoryIssuesViewController
        vc?.issueStatus = issuesStatusUrl
        
       if let navi = navigationVC {
            navi.pushViewController(vc!, animated: true)
        } else {
            self.navigationController?.pushViewController(vc!, animated: true)
        }
    }
}
