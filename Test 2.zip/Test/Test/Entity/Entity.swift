//
//  Entity.swift
//  Test
//
//  Created by mituser on 07/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
import UIKit

class News: NSObject, Codable {
    var name: String?
    var fullDescription: String?
    var openIssues: Int?
    var language: String?
    var url: String?
    var ownerEntity: Owner?
    
    enum CodingKeys: String, CodingKey {
        case name
        case fullDescription = "description"
        case openIssues = "open_issues"
        case language = "language"
        case url
        case ownerEntity = "owner"
    }
    
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        try container.encode(fullDescription, forKey: .fullDescription)
        try container.encode(openIssues, forKey: .openIssues)
        try container.encode(language, forKey: .language)
        try container.encode(url, forKey: .url)
        try container.encode(ownerEntity, forKey: .ownerEntity)
    }
    
    required public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decode(String?.self, forKey: .name)
        fullDescription = try values.decode(String?.self, forKey: .fullDescription)
        openIssues = try values.decode(Int?.self, forKey: .openIssues)
        language = try values.decode(String?.self, forKey: .language)
        url = try values.decode(String?.self, forKey: .url)
        ownerEntity = try values.decode(Owner?.self, forKey: .ownerEntity)
    }
}

