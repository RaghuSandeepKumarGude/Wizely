//
//  RepositoryIssuesViewController.swift
//  Test
//
//  Created by mituser on 10/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import UIKit
import SVProgressHUD

class RepositoryIssuesViewController: UIViewController {
    
    @IBOutlet var listOfIssuesTableView: UITableView!
    var issueStatus: String?
    var listOfIssues:[IssuesStatus]?

    override func viewDidLoad() {
        super.viewDidLoad()
        let issueModel = RepositoryIssuesModel()
        let IssueViewModel = RepositoryIssuesViewModel(model:issueModel )
        guard let url = issueStatus else {
            showErrorAlert()
            return
        }
        SVProgressHUD.show()
        SVProgressHUD.setBackgroundColor(.lightGray)
        IssueViewModel.fetchRepositoryList(issuesStatusUrl: url) { (resposeData, err) in
            DispatchQueue.main.async {
                SVProgressHUD.dismiss()
                guard err == nil else {
                    self.showErrorAlert()
                    return
                }
                self.listOfIssues = resposeData
                self.listOfIssuesTableView.reloadData()
            }
        }
    }
    
    private func showErrorAlert() {
        let alert = UIAlertController(title: "Something went wrong", message: "", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

extension RepositoryIssuesViewController: UITableViewDelegate, UITableViewDataSource {
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {

        //Bottom Refresh
            if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height)
            {
                print("data")
        }
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listOfIssues?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Identifier", for: indexPath)
            as! HeadlineTableViewCell
        
        let headline = listOfIssues?[indexPath.row]
        
        if let authorName = headline?.user?.login {
           cell.authorName?.text = "Name: " + authorName
        }
        
        if let issuetitle = headline?.title {
            cell.issueTitle?.text = "Title: " + issuetitle
        }
        
        if let issueDescription = headline?.body {
            let attributedString = issueDescription.data(using: .utf8).flatMap { data -> NSAttributedString? in
                return try? NSAttributedString(
                    data: data,
                    options: [
                        .documentType: NSAttributedString.DocumentType.html,
                        .characterEncoding: String.Encoding.utf8.rawValue
                    ],
                    documentAttributes: nil)
            }
            guard let attrString = attributedString else { return  cell }
            cell.issueDescription.attributedText = attrString
        }
        
        if let imageUrl = headline?.user?.avatarUrl {
            cell.authorImage?.sd_setImage(with: URL(string: imageUrl),
                                          placeholderImage: UIImage(named: "Thumbnail"),
                                          options: .retryFailed,
                                          completed: nil)
        }
        return cell
    }
}

class  HeadlineTableViewCell: UITableViewCell {
    @IBOutlet var issueDescription: UILabel!
    @IBOutlet var issueTitle: UILabel!
    @IBOutlet var authorName: UILabel!
    @IBOutlet var authorImage: UIImageView!
}
