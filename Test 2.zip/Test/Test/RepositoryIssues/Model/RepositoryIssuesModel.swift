//
//  RepositoryDetailModel.swift
//  Test
//
//  Created by mituser on 09/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation

typealias userInfoHandler = ([IssuesStatus]?, Error?) -> Void

class RepositoryIssuesModel: NSObject, RepositoryIssueModelProtocol {
    private var session: URLSession
    init(session: URLSession) {
        self.session = session
    }
    
    convenience override init () {
        self.init(session: URLSession(configuration: .default))
    }
    
    func makeUserInfoRequest(issuesStatusUrl: String, completionhandlers: @escaping userInfoHandler) {
        userInfoRepo(issuesStatusUrl: issuesStatusUrl, completion: completionhandlers)
    }
    
    private func userInfoRepo(issuesStatusUrl: String, completion: @escaping userInfoHandler) {
        let usersApiString = issuesStatusUrl
        
        guard let usersApi = URL(string: usersApiString) else {
            completion(nil, FeedError.invalidUrl)
            return
        }
        let task =  session.dataTask(with: usersApi) { (data, _, error) in
            guard let responseData = data, error == nil else {
                completion(nil, error)
                return
            }
            do {
                let decoder = JSONDecoder()
                let feed = try decoder.decode([IssuesStatus].self, from: responseData)
                completion(feed, nil)
            } catch let error {
                completion(nil, error)
            }
        }
        task.resume()
    }
}
