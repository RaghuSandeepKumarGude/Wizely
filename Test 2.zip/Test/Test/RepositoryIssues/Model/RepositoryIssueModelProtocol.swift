//
//  RepositoryIssueModelProtocol.swift
//  Test
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation

protocol  RepositoryIssueModelProtocol {
    func makeUserInfoRequest(issuesStatusUrl: String, completionhandlers: @escaping userInfoHandler)
}
