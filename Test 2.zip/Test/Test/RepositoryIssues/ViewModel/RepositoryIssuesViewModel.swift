//
//  RepositoryDetailViewModel.swift
//  Test
//
//  Created by mituser on 09/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation

class RepositoryIssuesViewModel: NSObject,RepositoryIssuesViewModelProtocol {
    var model: RepositoryIssueModelProtocol?
    
    init(model: RepositoryIssueModelProtocol) {
        self.model = model
    }
    
    func fetchRepositoryList(issuesStatusUrl: String, completion: @escaping userInfoHandler) {
        model?.makeUserInfoRequest(issuesStatusUrl: issuesStatusUrl, completionhandlers: { (responseData, err) in
            completion(responseData, err)
        })
    }
}
