//
//  RepositoryIssuesViewModelProtocol.swift
//  Test
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation

protocol  RepositoryIssuesViewModelProtocol {
     func fetchRepositoryList(issuesStatusUrl: String, completion: @escaping userInfoHandler)
}
