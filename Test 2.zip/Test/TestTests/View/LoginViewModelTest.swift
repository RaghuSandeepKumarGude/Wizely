//
//  LoginViewModelTest.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//


import Foundation
import XCTest
@testable import Test

class LoginViewModelTest: XCTestCase {
    var sut: LoginViewModel!
    var mockModel: MockloginModel!
    
    override func setUp() {
        super.setUp()
        mockModel = MockloginModel()
        sut = LoginViewModel(model: mockModel)
    }
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    func testFetchRepositoryList() {
        let expection = self.expectation(description: "testmakeListOfGitRepoRequest_SuccessResponse")
        sut.fetchRepositoryList(withRepoName: "test", OrganizationName: "test") { (data, err) in
            expection.fulfill()
        }
        wait(for: [expection], timeout: 10)
        XCTAssertTrue(mockModel.makeListOfGitRepoRequestCalled)
    }
}
