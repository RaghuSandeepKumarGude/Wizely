//
//  LoginModelTest.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
import XCTest
@testable import Test

class LoginModelTest: XCTestCase {
    var sut: LoginModel!
    var mockSession: MockSessionHelper.MockDataSession!
    
    override func setUp() {
        super.setUp()
        mockSession = MockSessionHelper.MockDataSession(isRepoInfo: true)
        sut = LoginModel(session: mockSession)
    }
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    func testmakeListOfGitRepoRequest_SuccessResponse() {
        let expection = self.expectation(description: "testmakeListOfGitRepoRequest_SuccessResponse")
        sut.makeListOfGitRepoRequest(withRepoName: "Alamofire", OrganizationName:  "Alamofire") { (data, err) in
           XCTAssertNotNil(data)
            expection.fulfill()
        }
        wait(for: [expection], timeout: 10)
    }
}
