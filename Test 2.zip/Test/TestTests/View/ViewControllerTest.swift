//
//  ViewControllerTest.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
import XCTest
@testable import Test

class ViewControllerTest: XCTestCase {
    var sut: ViewController!
 
    override func setUp() {
        super.setUp()
        sut = ViewController()
    }
    
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    func testSubmitRepositoryDetails() {
    }
}
