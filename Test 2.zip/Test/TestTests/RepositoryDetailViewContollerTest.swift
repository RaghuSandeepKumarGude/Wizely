//
//  RepositoryDetailView.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
import XCTest
@testable import Test

class RepositoryDetailViewContollerTest: XCTestCase {
    var sut: RepositoryDetailViewController!
    var navigation: MockNavigationController!
    
    var closedButton: UIButton {
        let issuesButton = UIButton()
        issuesButton.setTitle("Closed", for: .normal)
        return issuesButton
    }
    
    override func setUp() {
        super.setUp()
        sut = RepositoryDetailViewController()
        navigation = MockNavigationController()
    }
    
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    func testStatusOfTheIssues() throws {
        let button = closedButton
        sut.navigationVC = navigation
        let mockNewsDetails = MockObjects()
        sut.dataModel = try mockNewsDetails.mockEntityModel()
        sut.statusOfTheIssues(button)
        XCTAssertNotNil(navigation.pushedViewController)
    }

}
