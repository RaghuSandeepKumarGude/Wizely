//
//  MockrepositoryModel.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
@testable import Test

class MockrepositoryModel: RepositoryIssueModelProtocol {
    var makeUserInfoRequestCalled = false
    func makeUserInfoRequest(issuesStatusUrl: String, completionhandlers: @escaping userInfoHandler) {
        makeUserInfoRequestCalled = true
        completionhandlers(nil, nil)
    }
}
