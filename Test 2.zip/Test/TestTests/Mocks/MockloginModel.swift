//
//  MockloginModel.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
@testable import Test

class MockloginModel: LoginModelProtocol {
    var makeListOfGitRepoRequestCalled = false
    func makeListOfGitRepoRequest(withRepoName: String, OrganizationName: String, completionhandlers: @escaping responseHandler) {
        makeListOfGitRepoRequestCalled = true
        completionhandlers(nil, nil)
    }
}
