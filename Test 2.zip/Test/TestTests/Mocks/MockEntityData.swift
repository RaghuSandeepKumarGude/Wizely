//
//  MockEntityData.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
@testable import Test

struct MockObjects {
    func mockEntityModel() throws -> News? {
        var newsData: Data?
        var feed: News?
        guard let bundlePath = Bundle.main.url(forResource: "SampleJsonReponse",
                                               withExtension: "json") else {
                                                return nil
        }
        do {
            newsData = try Data(contentsOf: bundlePath)
        }
        
        do {
            let decoder = JSONDecoder()
            print(String(decoding: newsData!, as: UTF8.self))
            feed = try decoder.decode(News.self, from: newsData!)
        } catch let error {
            print(error.localizedDescription)
        }
        return feed
    }
}

