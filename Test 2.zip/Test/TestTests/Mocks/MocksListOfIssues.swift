//
//  MocksListOfIssues.swift
//  TestTests
//
//  Created by mituser on 12/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
@testable import Test

struct MocksListOfIssues {
    func mockEntityModel() throws -> [IssuesStatus]? {
        var newsData: Data?
        var feed: [IssuesStatus]?
        guard let bundlePath = Bundle.main.url(forResource: "IsuesStatus",
                                               withExtension: "json") else {
                                                return nil
        }
        do {
            newsData = try Data(contentsOf: bundlePath)
        }
        do {
            let decoder = JSONDecoder()
            print(String(decoding: newsData!, as: UTF8.self))
            feed = try decoder.decode([IssuesStatus].self, from: newsData!)
        } catch let error {
            print(error.localizedDescription)
        }
        return feed
    }
}
