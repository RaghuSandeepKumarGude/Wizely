//
//  RepositoryIssueViewContollerTest.swift
//  TestTests
//
//  Created by mituser on 12/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
import XCTest
@testable import Test

class RepositoryIssueViewContollerTest: XCTestCase {
    var sut: RepositoryIssuesViewController!
    var navigation: MockNavigationController!
    
    override func setUp() {
        super.setUp()
        sut = RepositoryIssuesViewController()
//        navigation = MockNavigationController()
    }
    
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    

    func testnumberOfRowsInSection() throws {
        let tableview = UITableView()
        let mockIssueDetails = MocksListOfIssues()
        sut.listOfIssues = try mockIssueDetails.mockEntityModel()
       let numberOfRows =  sut.tableView(tableview, numberOfRowsInSection: 1)
        XCTAssertEqual(numberOfRows, 25)
    }
}
