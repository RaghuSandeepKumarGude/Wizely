//
//  AppdelegateTest.swift
//  TestTests
//
//  Created by mituser on 12/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
import XCTest
@testable import Test

class AppdelegateTest: XCTestCase {
    var sut: AppDelegate!
    var application: UIApplication!
    override func setUp() {
        super.setUp()
        sut = AppDelegate()
        application = UIApplication.shared
    }
    
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    func testApplicationDidFinishLaunchingWithOptions() {
        let window = UIWindow(frame: UIScreen.main.bounds)
        sut.window = window
        XCTAssertTrue(sut.application(application,
                                      didFinishLaunchingWithOptions: [:]))
        
    }
    
    func testApplicationWillResignActive() {
        sut.applicationWillResignActive(application)
    }
    
    func testApplicationDidEnterBackground() {
        sut.applicationDidEnterBackground(application)
    }
    
    func testApplicationWillEnterForeground() {
        sut.applicationWillEnterForeground(application)
    }
    
    func testApplicationDidBecomeActive() {
        sut.applicationDidBecomeActive(application)
    }
    
    func testApplicationWillTerminate() {
        sut.applicationWillTerminate(application)
    }
}
