//
//  RepositoryDetailModelTest.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
import XCTest
@testable import Test

class RepositoryDetailModelTest: XCTestCase {
    var sut: RepositoryIssuesModel!
    var mockSession: MockSessionHelper.MockDataSession!
    
    override func setUp() {
        super.setUp()
        mockSession = MockSessionHelper.MockDataSession(isRepoInfo: false)
        sut = RepositoryIssuesModel(session: mockSession)
    }
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    func testmakeUserInfoRequest_SuccessResponse() {
        let expection = self.expectation(description: "testMostViewed")
        sut.makeUserInfoRequest(issuesStatusUrl: "www.abc.om") { (data, err) in
            XCTAssertNotNil(data)
            expection.fulfill()
        }
        wait(for: [expection], timeout: 10)
    }
}
