//
//  RepositoryViewModelTest.swift
//  TestTests
//
//  Created by mituser on 11/12/18.
//  Copyright © 2018 mituser. All rights reserved.
//

import Foundation
import XCTest
@testable import Test

class RepositoryViewModelTest: XCTestCase {
    var sut: RepositoryIssuesViewModel!
    var mockModel: MockrepositoryModel!
    
    override func setUp() {
        super.setUp()
        mockModel = MockrepositoryModel()
        sut = RepositoryIssuesViewModel(model: mockModel)
    }
    
    override func tearDown() {
        sut = nil
        super.tearDown()
    }
    
    func testFetchRepositoryList() {
        let expection = self.expectation(description: "testFetchRepositoryList")
        sut.fetchRepositoryList(issuesStatusUrl: "Test") { (data, err) in
            expection.fulfill()
        }
        wait(for: [expection], timeout: 10)
        XCTAssertTrue(mockModel.makeUserInfoRequestCalled)
    }
}
